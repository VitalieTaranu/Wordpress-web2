<?php

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u792781697_8I9kJ' );

/** Database username */
define( 'DB_USER', 'u792781697_8Qh4T' );

/** Database password */
define( 'DB_PASSWORD', 't94Wjoa38B' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'u>o>})`IQ1#mPkZoN3RnoDF[J[c;+GfwXg8LtC+H*cC+E./WAQ=BpSq80+y5Z`sW' );
define( 'SECURE_AUTH_KEY',   'YgBYaPa s|*xyj(P9-C:H4Ac8c+?x9L;@+}Kd^$)+h>EZD.z|%KJH(_fWJm%LN95' );
define( 'LOGGED_IN_KEY',     '>g:fJ^[ncp$y2+r40]AEue(ZzC,dKmJ}S_UP9[KAY_IvdZZ6/1t-O(+vnaz1H US' );
define( 'NONCE_KEY',         ')3< j]TM_$*[cKX/Bu}xYVXaP1#fC:v%p&oVr6b&Yh{49RtD p:%E8<kRd(R(Nk:' );
define( 'AUTH_SALT',         ')N.k-YwSq<+g<}[3Etl6DpocvG7vDm;pGz2%@tD}F>)Esrl>~~2$A! 7/9]>1xh[' );
define( 'SECURE_AUTH_SALT',  'r1$:4MQWVmFW9 ;qB@6v!T[(gMy`} }wYn+LL~yg$?1`?P7X]0)C}.obawAa(hXV' );
define( 'LOGGED_IN_SALT',    '+KTh+jNB;40J#< }HeviG=a{gg>;=mq$<iN/$y5V(NQcvog-3X8 NnAXg,L Ug_0' );
define( 'NONCE_SALT',        'Q~Q7_]c&PEm,yFiE+qwvH$NM{~; Qfzmv)SF< r=D!JIP!J.~4_w}~$F4b3/.vs!' );
define( 'WP_CACHE_KEY_SALT', '_:<;}?Ju%kVDWlt QO/VYA7z0=)>?8% j8.SbNnc39j;U(oH5YmR3wB:fp[Luk+*' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
